package com.example.SpringBootSecurity66;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurity66Application {

	public static void main(String[] args) {

		SpringApplication.run(SpringBootSecurity66Application.class, args);
		long endTime=System.currentTimeMillis();
		System.out.println(endTime);
	}

}
